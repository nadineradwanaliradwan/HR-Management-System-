package Models;

import org.junit.jupiter.api.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.jupiter.api.Assertions.*;

/**
 * White‑box tests for {@link PerformanceEvaluation}.
 *
 * ▪ High code‑coverage – every public method, branch and boundary exercised.
 * ▪ Early logic‑error detection – explicit assertions on the internal state.
 * ▪ Verification of all paths – separate tests for each decision outcome.
 * ▪ Code‑quality feedback – guards against regressions (rating < 0 or > 100).
 *
 * NOTE:  If your Employee constructor differs, adapt the setUp() helper
 *        or replace the real object with a Mockito spy/mock.
 */
class PerformanceEvaluationTestW {

    private Employee emp;                // fresh employee for each test
    private PrintStream stdOutBak;       // keep original System.out
    private ByteArrayOutputStream out;   // capture console output

    /* ---------- Test Harness ---------- */

    @BeforeEach
    void setUp() {
        // Suitable constructor from your own Employee class
        emp = new Employee(
                1, "John Doe", "IT", "Developer",
                50_000,          // salary
                30,              // remaining leave
                100.0,           // initial performance
                "pwd"
        );

        // Hijack System.out so we can assert on printed reports
        stdOutBak = System.out;
        out = new ByteArrayOutputStream();
        System.setOut(new PrintStream(out));
    }

    @AfterEach
    void tearDown() {
        System.setOut(stdOutBak);        // restore console
    }

    /* ---------- calculatePerformanceRate() ---------- */

    @Nested
    @DisplayName("Automatic performance calculation")
    class AutoCalc {

        @Test
        @DisplayName("No leave taken ⇒ rating stays 100 %")
        void zeroLeave() {
            PerformanceEvaluation.calculatePerformanceRate(emp, 30);
            assertEquals(100, emp.getPerformanceRating());
        }

        @Test
        @DisplayName("11‑20 days used ⇒ –10 %")
        void moderateLeave() {
            PerformanceEvaluation.calculatePerformanceRate(emp, 15);   // 15 used
            assertEquals(90, emp.getPerformanceRating());
        }

        @Test
        @DisplayName("21+ days used ⇒ –20 %")
        void heavyLeave() {
            PerformanceEvaluation.calculatePerformanceRate(emp, 5);    // 25 used
            assertEquals(80, emp.getPerformanceRating());
        }
    }

    /* ---------- setPerformanceManually() ---------- */

    @Nested
    @DisplayName("Manual rating override")
    class Manual {

        @Test
        @DisplayName("Accepts valid rating in [0, 100]")
        void validManualSet() {
            PerformanceEvaluation.setPerformanceManually(emp, 55.5);
            assertEquals(55.5, emp.getPerformanceRating());
        }

        @Test
        @DisplayName("Rejects out‑of‑range rating")
        void invalidManualSet() {
            PerformanceEvaluation.setPerformanceManually(emp, 150);    // too high
            assertEquals(100, emp.getPerformanceRating(),           // unchanged
                    "Rating must remain untouched when input is invalid");
            assertTrue(out.toString().contains("Invalid performance rating"));
        }
    }

    /* ---------- boostPerformance() ---------- */

    @Nested
    @DisplayName("Positive boosts")
    class Boost {

        @Test
        @DisplayName("Nominal boost increases rating")
        void boostWithinRange() {
            emp.setPerformanceRating(80);
            PerformanceEvaluation.boostPerformance(emp, 10);
            assertEquals(90, emp.getPerformanceRating());
        }

        @Test
        @DisplayName("Boost never exceeds 100 %")
        void boostCapped() {
            emp.setPerformanceRating(95);
            PerformanceEvaluation.boostPerformance(emp, 10);
            assertEquals(100, emp.getPerformanceRating());
        }
    }

    /* ---------- penalizePerformance() ---------- */

    @Nested
    @DisplayName("Negative penalties")
    class Penalty {

        @Test
        @DisplayName("Nominal penalty decreases rating")
        void penaltyWithinRange() {
            emp.setPerformanceRating(50);
            PerformanceEvaluation.penalizePerformance(emp, 20);
            assertEquals(30, emp.getPerformanceRating());
        }

        @Test
        @DisplayName("Rating never drops below 0 %")
        void penaltyFloored() {
            emp.setPerformanceRating(5);
            PerformanceEvaluation.penalizePerformance(emp, 20);
            assertEquals(0, emp.getPerformanceRating());
        }
    }

    /* ---------- displayPerformance() ---------- */

    @Test
    @DisplayName("Report prints the expected summary")
    void displayReport() {
        emp.setPerformanceRating(88);
        PerformanceEvaluation.displayPerformance(emp);

        String report = out.toString();  // entire console dump
        assertAll("Report format",
                () -> assertTrue(report.contains("Employee ID   : 1")),
                () -> assertTrue(report.contains("Name          : John Doe")),
                () -> assertTrue(report.contains("Rating        : 88.0%"))
        );
    }
}
