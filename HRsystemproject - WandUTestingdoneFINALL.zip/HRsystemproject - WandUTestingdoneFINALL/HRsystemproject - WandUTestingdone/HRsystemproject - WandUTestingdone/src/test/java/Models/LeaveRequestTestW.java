package Models;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

/**
 * White‑box tests for {@link LeaveRequest}.
 *
 * ▪ High code coverage – every constructor path, getter & setter hit.
 * ▪ Early detection of logical errors – explicit assertions on all
 *   state changes.
 * ▪ Verification of all paths – approval flag toggled true ↔ false,
 *   multiple date combinations.
 * ▪ Code‑optimisation input – edge‑case tests (nulls / same‑day leave)
 *   reveal where validation could be tightened.
 * ▪ Security / quality signal – confirms object tolerates null Employee
 *   (should that be allowed?).  Failing these later = "regression caught".
 */
class LeaveRequestTestW {

    /* ------------------------------------------------------------------
       Test‑data helpers
       ------------------------------------------------------------------ */
    private static Employee dummyEmployee(int id) {
        // Minimal throw‑away implementation; the real Employee class is
        // richer, but we only need an identity placeholder for these tests.
        return new Employee(id, "Dummy", "IT", "Dev",
                0.0, 0, 0.0, "pw");
    }

    // ---------- Happy‑path constructor coverage ----------
    @Test
    @DisplayName("Constructor stores employee ref + dates and defaults approval to false")
    void ctor_populatesFields_correctly() {
        Employee emp = dummyEmployee(111);
        LocalDate start = LocalDate.of(2025, 6, 1);
        LocalDate end   = LocalDate.of(2025, 6, 5);

        LeaveRequest lr = new LeaveRequest(emp, start, end);

        assertAll("field values",
                () -> assertSame(emp,  lr.getEmployeeId()),
                () -> assertEquals(start, lr.getStartDate()),
                () -> assertEquals(end,   lr.getEndDate()),
                () -> assertFalse(lr.isApproved(), "approval flag starts false")
        );
    }

    // ---------- Setter / getter path coverage ----------
    @Nested
    @DisplayName("setApproved toggles state and getters reflect change")
    class ApprovalMutator {

        @Test
        void setApproved_true_then_false() {
            LeaveRequest lr = new LeaveRequest(
                    dummyEmployee(200),
                    LocalDate.now().plusDays(1),
                    LocalDate.now().plusDays(3));

            lr.setApproved(true);
            assertTrue(lr.isApproved(), "flag should flip to true");

            lr.setApproved(false);
            assertFalse(lr.isApproved(), "flag should flip back to false");
        }
    }

    // ---------- Parameterised date‑range exploration ----------
    @ParameterizedTest(name = "start {0}  –  end {1}")
    @CsvSource({
            // same‑day leave
            "2025-01-01, 2025-01-01",
            // spanning month
            "2025-03-30, 2025-04-02",
            // spanning year
            "2025-12-31, 2026-01-02"
    })
    @DisplayName("Getter returns exact start/end supplied to constructor")
    void getters_returnExactDates(String startStr, String endStr) {
        LocalDate start = LocalDate.parse(startStr);
        LocalDate end   = LocalDate.parse(endStr);

        LeaveRequest lr = new LeaveRequest(dummyEmployee(77), start, end);

        assertAll(
                () -> assertEquals(start, lr.getStartDate()),
                () -> assertEquals(end,   lr.getEndDate())
        );
    }

    // ---------- Edge‑case tests reveal potential hardening needs ----------
    @Test
    @DisplayName("Null arguments currently accepted – consider validation")
    void allowsNulls_pointsToMissingValidation() {
        LeaveRequest lr = new LeaveRequest(null, null, null);

        assertAll(
                () -> assertNull(lr.getEmployeeId()),
                () -> assertNull(lr.getStartDate()),
                () -> assertNull(lr.getEndDate())
        );
    }

    @Test
    @DisplayName("Test end date before start date - should be handled")
    void endDateBeforeStartDate() {
        Employee emp = dummyEmployee(111);
        LocalDate start = LocalDate.of(2025, 6, 5);
        LocalDate end = LocalDate.of(2025, 6, 1);

        LeaveRequest lr = new LeaveRequest(emp, start, end);
        
        assertAll(
                () -> assertEquals(start, lr.getStartDate()),
                () -> assertEquals(end, lr.getEndDate())
        );
    }

    @Test
    @DisplayName("Test same employee with different leave requests")
    void sameEmployeeDifferentRequests() {
        Employee emp = dummyEmployee(111);
        LocalDate start1 = LocalDate.of(2025, 6, 1);
        LocalDate end1 = LocalDate.of(2025, 6, 5);
        LocalDate start2 = LocalDate.of(2025, 7, 1);
        LocalDate end2 = LocalDate.of(2025, 7, 5);

        LeaveRequest lr1 = new LeaveRequest(emp, start1, end1);
        LeaveRequest lr2 = new LeaveRequest(emp, start2, end2);

        assertAll(
                () -> assertSame(emp, lr1.getEmployeeId()),
                () -> assertSame(emp, lr2.getEmployeeId()),
                () -> assertNotEquals(lr1.getStartDate(), lr2.getStartDate()),
                () -> assertNotEquals(lr1.getEndDate(), lr2.getEndDate())
        );
    }
}
