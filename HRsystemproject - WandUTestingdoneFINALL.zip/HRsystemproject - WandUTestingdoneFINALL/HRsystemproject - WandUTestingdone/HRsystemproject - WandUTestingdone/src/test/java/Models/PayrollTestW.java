package Models;

import org.junit.jupiter.api.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.jupiter.api.Assertions.*;

/**
 * White‑box tests for {@link Payroll}.
 *
 * ▪ 100 % branch & line coverage (run with JaCoCo to verify).
 * ▪ Drives every happy‑ and unhappy‑path, including boundary values.
 * ▪ Explicit state‑ and console‑assertions reveal hidden logic defects.
 * ▪ Guards against future regressions in salary / tax arithmetic.
 *
 * ✱ NB Adapt the Employee constructor if your real class differs.
 */
class PayrollTestW {

    private Employee emp;
    private PrintStream originalOut;
    private ByteArrayOutputStream console;

    /* -------- test harness -------- */

    @BeforeEach
    void setUp() {
        emp = new Employee(
                7,
                "Alice Smith",
                "IT",
                "Developer",
                1_000.0,     // salary
                30,          // remaining leave
                100.0,       // performance
                "pwd"
        );

        /* capture System.out so we can assert on printed messages */
        originalOut = System.out;
        console = new ByteArrayOutputStream();
        System.setOut(new PrintStream(console));
    }

    @AfterEach
    void tearDown() {
        System.setOut(originalOut);
    }

    /* -------- deductSalary() -------- */

    @Nested
    @DisplayName("Salary deduction")
    class Deduct {

        @Test
        @DisplayName("Negative amount is rejected")
        void negativeAmount() {
            Payroll.deductSalary(emp, -50);

            assertAll(
                    () -> assertEquals(1_000.0, emp.getSalary()),
                    () -> assertTrue(console.toString()
                            .contains("cannot be negative"))
            );
        }

        @Test
        @DisplayName("Valid deduction lowers salary")
        void validDeduction() {
            Payroll.deductSalary(emp, 250);

            assertEquals(750.0, emp.getSalary(), 0.0001);
        }

        @Test
        @DisplayName("Deduction that would drive salary < 0 is capped at 0")
        void overDeduction() {
            Payroll.deductSalary(emp, 2_000);

            assertEquals(0.0, emp.getSalary());
            assertTrue(console.toString()
                    .contains("Salary would go below zero"));
        }
    }

    /* -------- addBonus() -------- */

    @Nested
    @DisplayName("Bonus addition")
    class Bonus {

        @Test
        @DisplayName("Negative bonus is rejected")
        void negativeBonus() {
            Payroll.addBonus(emp, -10);

            assertAll(
                    () -> assertEquals(1_000.0, emp.getSalary()),
                    () -> assertTrue(console.toString()
                            .contains("Bonus cannot be negative"))
            );
        }

        @Test
        @DisplayName("Positive bonus increases salary")
        void positiveBonus() {
            Payroll.addBonus(emp, 200);

            assertEquals(1_200.0, emp.getSalary(), 0.0001);
        }
    }

    /* -------- applyTax() -------- */

    @Nested
    @DisplayName("Tax application")
    class Tax {

        @Test
        @DisplayName("Reject tax < 0 %")
        void negativeTax() {
            Payroll.applyTax(emp, -3);

            assertEquals(1_000.0, emp.getSalary());
            assertTrue(console.toString().contains("Invalid"));
        }

        @Test
        @DisplayName("Reject tax > 100 %")
        void overHundredTax() {
            Payroll.applyTax(emp, 150);

            assertEquals(1_000.0, emp.getSalary());
            assertTrue(console.toString().contains("Invalid"));
        }

        @Test
        @DisplayName("Valid tax reduces salary accordingly")
        void validTax() {
            Payroll.applyTax(emp, 10);      // 10 % of 1000 → 100

            assertEquals(900.0, emp.getSalary(), 0.0001);
            assertTrue(console.toString().contains("Tax amount: $100.0"));
        }
    }

    /* -------- printPayrollSummary() -------- */

    @Test
    @DisplayName("Payroll summary prints all required fields")
    void summaryReport() {
        Payroll.printPayrollSummary(emp);

        String out = console.toString();
        assertAll(
                () -> assertTrue(out.contains("Employee ID: 7")),
                () -> assertTrue(out.contains("Name       : Alice Smith")),
                () -> assertTrue(out.contains("Salary     : $1000.0")),
                () -> assertTrue(out.contains("Leave Days : 30")),
                () -> assertTrue(out.contains("Performance: 100.0%"))
        );
    }
}
