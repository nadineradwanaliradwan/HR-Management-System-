package Models;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class LeaveRequestTest {

    private LeaveRequest leaveRequest;
    private Employee testEmployee;
    private LocalDate start;
    private LocalDate end;

    @BeforeEach
    void setUp() {
        testEmployee = new Employee(1001, "Nadine", "IT", "Developer", 6000.0, 30, 100.0, "pass123");
        start = LocalDate.of(2025, 5, 10);
        end = LocalDate.of(2025, 5, 15);
        leaveRequest = new LeaveRequest(testEmployee, start, end);
    }

    @Test
    void getEmployeeId_shouldReturnCorrectEmployee() {
        assertEquals(testEmployee, leaveRequest.getEmployeeId());
        assertEquals("Nadine", leaveRequest.getEmployeeId().getName());
        assertEquals("IT", leaveRequest.getEmployeeId().getDepartment());
    }

    @Test
    void getStartDate_shouldReturnCorrectStartDate() {
        assertEquals(start, leaveRequest.getStartDate());
    }

    @Test
    void getEndDate_shouldReturnCorrectEndDate() {
        assertEquals(end, leaveRequest.getEndDate());
    }

    @Test
    void isApproved_shouldBeFalseInitially() {
        assertFalse(leaveRequest.isApproved());
    }

    @Test
    void setApproved_shouldChangeApprovalStatus() {
        leaveRequest.setApproved(true);
        assertTrue(leaveRequest.isApproved());

        leaveRequest.setApproved(false);
        assertFalse(leaveRequest.isApproved());
    }
}
