package Models;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PerformanceEvaluationTest {

    private Employee employee;

    @BeforeEach
    void setUp() {
        employee = new Employee(1, "Test User", "IT", "Dev", 5000.0, 30, 100.0, "test123");
    }

    @Test
    void calculatePerformanceRate_noLeaveUsed_shouldStay100() {
        PerformanceEvaluation.calculatePerformanceRate(employee, 30); // Used 0 days
        assertEquals(100.0, employee.getPerformanceRating(), 0.01);
    }

    @Test
    void calculatePerformanceRate_used15Days_shouldBe90() {
        PerformanceEvaluation.calculatePerformanceRate(employee, 15); // Used 15 days
        assertEquals(90.0, employee.getPerformanceRating(), 0.01);
    }

    @Test
    void calculatePerformanceRate_used25Days_shouldBe80() {
        PerformanceEvaluation.calculatePerformanceRate(employee, 5); // Used 25 days
        assertEquals(80.0, employee.getPerformanceRating(), 0.01);
    }

    @Test
    void calculatePerformanceRate_usedOver30_shouldNotBeNegative() {
        PerformanceEvaluation.calculatePerformanceRate(employee, -5); // Used 35 days (invalid input)
        assertEquals(80.0, employee.getPerformanceRating(), 0.01); // Still clamps to minimum 80 as per your logic
    }

    @Test
    void setPerformanceManually_validValue_shouldUpdate() {
        PerformanceEvaluation.setPerformanceManually(employee, 75.5);
        assertEquals(75.5, employee.getPerformanceRating(), 0.01);
    }

    @Test
    void setPerformanceManually_invalidNegativeValue_shouldIgnore() {
        PerformanceEvaluation.setPerformanceManually(employee, -10);
        assertEquals(100.0, employee.getPerformanceRating(), 0.01); // Unchanged
    }

    @Test
    void setPerformanceManually_above100_shouldIgnore() {
        PerformanceEvaluation.setPerformanceManually(employee, 120);
        assertEquals(100.0, employee.getPerformanceRating(), 0.01); // Unchanged
    }

    @Test
    void boostPerformance_withinLimit_shouldIncrease() {
        employee.setPerformanceRating(80);
        PerformanceEvaluation.boostPerformance(employee, 10);
        assertEquals(90.0, employee.getPerformanceRating(), 0.01);
    }

    @Test
    void boostPerformance_above100_shouldClamp() {
        employee.setPerformanceRating(95);
        PerformanceEvaluation.boostPerformance(employee, 20);
        assertEquals(100.0, employee.getPerformanceRating(), 0.01);
    }

    @Test
    void penalizePerformance_withinLimit_shouldDecrease() {
        employee.setPerformanceRating(90);
        PerformanceEvaluation.penalizePerformance(employee, 20);
        assertEquals(70.0, employee.getPerformanceRating(), 0.01);
    }

    @Test
    void penalizePerformance_belowZero_shouldClamp() {
        employee.setPerformanceRating(10);
        PerformanceEvaluation.penalizePerformance(employee, 50);
        assertEquals(0.0, employee.getPerformanceRating(), 0.01);
    }

    @Test
    void displayPerformance_shouldNotThrow() {
        assertDoesNotThrow(() -> PerformanceEvaluation.displayPerformance(employee));
    }
}
