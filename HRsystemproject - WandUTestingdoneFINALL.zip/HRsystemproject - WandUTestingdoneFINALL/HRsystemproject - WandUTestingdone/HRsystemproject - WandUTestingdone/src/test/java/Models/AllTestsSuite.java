package Models;

import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;

/**
 * Test suite to run all white-box tests in the Models package.
 * Ensures maximum code coverage by executing all test classes.
 */
@Suite
@SelectClasses({
        EmployeeTestW.class,
        LeaveRequestTestW.class,
        PayrollTestW.class,
        PerformanceEvaluationTestW.class,
})
public class AllTestsSuite {
    // No additional code needed; the annotations handle test execution.
}