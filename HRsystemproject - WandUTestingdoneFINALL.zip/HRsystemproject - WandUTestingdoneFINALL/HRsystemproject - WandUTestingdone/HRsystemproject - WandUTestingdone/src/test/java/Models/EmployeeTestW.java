package Models;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * White‑box tests for {@link Employee}.
 *
 * ▪ High code coverage – every constructor, getter, setter & toString invoked.
 * ▪ Early detection of logical errors – explicit assertions on field values.
 * ▪ Verification of all paths – both constructors & each mutator path tested.
 * ▪ Code‑quality feedback – edge‑case tests (e.g., negative salary) expose
 *   missing validation, guiding future hardening.
 * ▪ Security awareness – test that password is stored & returned intact
 *   (later you might hash instead, and these tests will fail appropriately).
 */
class EmployeeTestW {

    // ---------- Happy‑path constructor coverage ----------
    @Test
    @DisplayName("Full‑argument constructor sets all fields correctly")
    void ctor_fullArgs_populatesAllFields() {
        Employee e = new Employee(
                101, "Nadine", "IT", "Engineer",
                12_500.0, 15, 99.2, "pw123"
        );

        assertAll("field values",
                () -> assertEquals(101, e.getEmployeeId()),
                () -> assertEquals("Nadine", e.getName()),
                () -> assertEquals("IT", e.getDepartment()),
                () -> assertEquals("Engineer", e.getPosition()),
                () -> assertEquals(12_500.0, e.getSalary()),
                () -> assertEquals(15, e.getRemainingLeaveDays()),
                () -> assertEquals(99.2, e.getPerformanceRating()),
                () -> assertEquals("pw123", e.getPassword())
        );
    }

    @Test
    @DisplayName("Convenience constructor applies default leave + rating")
    void ctor_defaults_applyCorrectly() {
        Employee e = new Employee(
                102, "Hams", "HR", "Manager",
                22_000.0, "secure!"
        );

        assertAll("defaults & params",
                () -> assertEquals(30, e.getRemainingLeaveDays()),
                () -> assertEquals(100.0, e.getPerformanceRating()),
                () -> assertEquals(22_000.0, e.getSalary()),
                () -> assertEquals("secure!", e.getPassword())
        );
    }

    // ---------- Setter / getter path coverage ----------
    @Nested
    @DisplayName("Setters mutate state and getters reflect the change")
    class MutatorCoverage {

        @Test void settersUpdateAllPrimitiveAndReferenceFields() {
            Employee e = new Employee(
                    1, "tmp", "tmp", "tmp",
                    1.0, 1, 1.0, "tmp");

            e.setEmployeeId(200);
            e.setName("Updated");
            e.setDepartment("SALES");
            e.setPosition("Lead");
            e.setSalary(50_000);
            e.setRemainingLeaveDays(18);
            e.setPerformanceRating(87.3);
            e.setPassword("newPw");

            assertAll("after mutation",
                    () -> assertEquals(200, e.getEmployeeId()),
                    () -> assertEquals("Updated", e.getName()),
                    () -> assertEquals("SALES", e.getDepartment()),
                    () -> assertEquals("Lead", e.getPosition()),
                    () -> assertEquals(50_000, e.getSalary()),
                    () -> assertEquals(18, e.getRemainingLeaveDays()),
                    () -> assertEquals(87.3, e.getPerformanceRating()),
                    () -> assertEquals("newPw", e.getPassword())
            );
        }
    }

    // ---------- Functional / representation test ----------
    @Test
    @DisplayName("toString follows the documented format")
    void toString_hasCorrectFormat() {
        Employee e = new Employee(55, "Yara", "MKT", "Head", 30_000, "pw");
        assertEquals("55 - Yara (Head)", e.toString());
    }

    // ---------- Edge‑case tests expose potential hardening needs ----------
    @Test
    @DisplayName("Negative salary is accepted – points to missing validation")
    void negativeSalary_currentlyAllowed() {
        Employee e = new Employee(7, "X", "IT", "Dev", -500.0, "pw");
        assertEquals(-500.0, e.getSalary(),
                "Specification may require salary ≥ 0; consider validation");
    }

    @Test
    @DisplayName("Null fields are permitted – highlight security/quality risk")
    void nullValues_currentlyAllowed() {
        Employee e = new Employee(9, null, null, null, 0.0, null);
        assertNull(e.getName());
        assertNull(e.getPassword());
    }
}
