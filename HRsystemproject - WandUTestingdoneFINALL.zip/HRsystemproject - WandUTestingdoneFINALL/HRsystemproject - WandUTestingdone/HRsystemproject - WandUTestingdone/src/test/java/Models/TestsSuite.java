package Models;

import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;

/**
 * running all normal test files
 */
@Suite
@SelectClasses({
        EmployeeTest.class,
        LeaveRequestTest.class,
        PayrollTest.class,
})
public class TestsSuite {
    // No additional code needed; the annotations handle test execution.
}