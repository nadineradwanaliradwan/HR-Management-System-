package Models;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class EmployeeTest {

    private Employee employee;

    @BeforeEach
    void setUp() {
        employee = new Employee(101, "John Doe", "IT", "Developer", 5000.0, 25, 85.0, "secret123");
    }

    @Test
    void testConstructorWithAllFields() {
        assertEquals(101, employee.getEmployeeId());
        assertEquals("John Doe", employee.getName());
        assertEquals("IT", employee.getDepartment());
        assertEquals("Developer", employee.getPosition());
        assertEquals(5000.0, employee.getSalary());
        assertEquals(25, employee.getRemainingLeaveDays());
        assertEquals(85.0, employee.getPerformanceRating());
        assertEquals("secret123", employee.getPassword());
    }

    @Test
    void testConstructorWithDefaults() {
        Employee e = new Employee(202, "Jane", "HR", "Manager", 6000.0, "pass456");
        assertEquals(202, e.getEmployeeId());
        assertEquals("Jane", e.getName());
        assertEquals("HR", e.getDepartment());
        assertEquals("Manager", e.getPosition());
        assertEquals(6000.0, e.getSalary());
        assertEquals(30, e.getRemainingLeaveDays()); // default
        assertEquals(100.0, e.getPerformanceRating()); // default
        assertEquals("pass456", e.getPassword());
    }

    @Test
    void getAndSetEmployeeId() {
        employee.setEmployeeId(202);
        assertEquals(202, employee.getEmployeeId());
    }

    @Test
    void getAndSetName() {
        employee.setName("Alice");
        assertEquals("Alice", employee.getName());
    }

    @Test
    void getAndSetDepartment() {
        employee.setDepartment("Marketing");
        assertEquals("Marketing", employee.getDepartment());
    }

    @Test
    void getAndSetPosition() {
        employee.setPosition("Lead");
        assertEquals("Lead", employee.getPosition());
    }

    @Test
    void getAndSetSalary() {
        employee.setSalary(7500.0);
        assertEquals(7500.0, employee.getSalary());
    }

    @Test
    void getAndSetRemainingLeaveDays() {
        employee.setRemainingLeaveDays(18);
        assertEquals(18, employee.getRemainingLeaveDays());
    }

    @Test
    void getAndSetPerformanceRating() {
        employee.setPerformanceRating(92.5);
        assertEquals(92.5, employee.getPerformanceRating());
    }

    @Test
    void getAndSetPassword() {
        employee.setPassword("newPass");
        assertEquals("newPass", employee.getPassword());
    }

    @Test
    void testToString() {
        assertEquals("101 - John Doe (Developer)", employee.toString());
    }
}
