package Models;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class LeaveManagementTest {

    private Employee employee;

    @BeforeEach
    void setUp() {
        employee = new Employee(1, "Test User", "IT", "Dev", 5000.0, 10, 90.0, "pass");
    }

    @Test
    void validateLeaveRequest_validCase_shouldReturnTrue() {
        LeaveRequest leave = new LeaveRequest(employee, LocalDate.now().plusDays(1), LocalDate.now().plusDays(3));
        assertTrue(LeaveManagement.validateLeaveRequest(employee, leave));
    }

    @Test
    void validateLeaveRequest_startDateBeforeToday_shouldReturnFalse() {
        LeaveRequest leave = new LeaveRequest(employee, LocalDate.now().minusDays(1), LocalDate.now().plusDays(1));
        assertFalse(LeaveManagement.validateLeaveRequest(employee, leave));
    }

    @Test
    void validateLeaveRequest_endBeforeStart_shouldReturnFalse() {
        LeaveRequest leave = new LeaveRequest(employee, LocalDate.now().plusDays(5), LocalDate.now().plusDays(3));
        assertFalse(LeaveManagement.validateLeaveRequest(employee, leave));
    }

    @Test
    void validateLeaveRequest_insufficientBalance_shouldReturnFalse() {
        LeaveRequest leave = new LeaveRequest(employee, LocalDate.now().plusDays(1), LocalDate.now().plusDays(15)); // 15 days
        assertFalse(LeaveManagement.validateLeaveRequest(employee, leave));
    }

    @Test
    void updateLeaveBalance_validCase_shouldDeductBalance() {
        LeaveRequest leave = new LeaveRequest(employee, LocalDate.now().plusDays(1), LocalDate.now().plusDays(3)); // 3 days
        int original = employee.getRemainingLeaveDays();

        LeaveManagement.updateLeaveBalance(leave, employee);

        assertEquals(original - 3, employee.getRemainingLeaveDays());
    }

    @Test
    void updateLeaveBalance_invalidCase_shouldNotDeduct() {
        LeaveRequest leave = new LeaveRequest(employee, LocalDate.now().plusDays(1), LocalDate.now().plusDays(15)); // 15 days
        int original = employee.getRemainingLeaveDays();

        LeaveManagement.updateLeaveBalance(leave, employee);

        // Should remain unchanged
        assertEquals(original, employee.getRemainingLeaveDays());
    }

    @Test
    void calculateLeaveDays_validDates_shouldReturnCorrectDays() {
        LocalDate start = LocalDate.of(2025, 4, 25);
        LocalDate end = LocalDate.of(2025, 4, 30);

        int days = LeaveManagement.calculateLeaveDays(start, end);
        assertEquals(6, days);
    }

    @Test
    void calculateLeaveDays_sameDay_shouldReturnOne() {
        LocalDate date = LocalDate.of(2025, 4, 25);
        int days = LeaveManagement.calculateLeaveDays(date, date);
        assertEquals(1, days);
    }

    @Test
    void displayLeaveRequest_shouldPrintDetails() {
        LeaveRequest leave = new LeaveRequest(employee, LocalDate.now().plusDays(2), LocalDate.now().plusDays(5));
        leave.setApproved(true);

        // Just verify it runs without exception
        assertDoesNotThrow(() -> LeaveManagement.displayLeaveRequest(leave));
    }
}
