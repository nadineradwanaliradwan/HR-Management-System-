package Models;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PayrollTest {

    private Employee employee;

    @BeforeEach
    void setUp() {
        // Initial setup for each test
        employee = new Employee(1, "Nadine", "IT", "Developer", 1000.0, 30, 100.0, "password123");
    }

    @Test
    void deductSalary_validAmount_shouldReduceSalary() {
        Payroll.deductSalary(employee, 200);
        assertEquals(800.0, employee.getSalary(), 0.01);
    }

    @Test
    void deductSalary_highAmount_shouldSetSalaryToZero() {
        Payroll.deductSalary(employee, 1200);
        assertEquals(0.0, employee.getSalary(), 0.01);
    }

    @Test
    void deductSalary_negativeAmount_shouldIgnoreDeduction() {
        Payroll.deductSalary(employee, -100);
        assertEquals(1000.0, employee.getSalary(), 0.01);
    }

    @Test
    void addBonus_validBonus_shouldIncreaseSalary() {
        Payroll.addBonus(employee, 150);
        assertEquals(1150.0, employee.getSalary(), 0.01);
    }

    @Test
    void addBonus_negativeBonus_shouldIgnoreAddition() {
        Payroll.addBonus(employee, -50);
        assertEquals(1000.0, employee.getSalary(), 0.01);
    }

    @Test
    void applyTax_validTax_shouldDeductCorrectAmount() {
        Payroll.applyTax(employee, 10); // 10% of 1000 = 100
        assertEquals(900.0, employee.getSalary(), 0.01);
    }

    @Test
    void applyTax_over100Percent_shouldIgnore() {
        Payroll.applyTax(employee, 150);
        assertEquals(1000.0, employee.getSalary(), 0.01);
    }

    @Test
    void applyTax_negativeTax_shouldIgnore() {
        Payroll.applyTax(employee, -5);
        assertEquals(1000.0, employee.getSalary(), 0.01);
    }

    @Test
    void printPayrollSummary_shouldNotThrow() {
        assertDoesNotThrow(() -> Payroll.printPayrollSummary(employee));
    }
}
