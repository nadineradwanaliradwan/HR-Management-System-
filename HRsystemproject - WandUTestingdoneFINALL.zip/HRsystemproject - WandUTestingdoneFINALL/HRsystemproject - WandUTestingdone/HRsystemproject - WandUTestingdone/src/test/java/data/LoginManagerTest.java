package data;

import Models.Employee;
import org.junit.jupiter.api.*;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class LoginManagerTest {

    private ArrayList<Employee> employeeList;
    private Employee hrEmployee;
    private Employee nonHrEmployee;

    @BeforeEach
    void setUp() {
        employeeList = new ArrayList<>();

        hrEmployee = new Employee(111, "Yasmine", "HR", "Manager", 5000.0, 30, 100.0, "passHR");
        nonHrEmployee = new Employee(222, "Omar", "IT", "Developer", 3000.0, 30, 100.0, "passIT");

        employeeList.add(hrEmployee);
        employeeList.add(nonHrEmployee);
    }

    @Test
    void authenticate_validCredentials_shouldReturnEmployee() {
        Employee result = LoginManager.authenticate(employeeList, 222, "passIT");
        assertNotNull(result);
        assertEquals("Omar", result.getName());
    }

    @Test
    void authenticate_invalidPassword_shouldReturnNull() {
        Employee result = LoginManager.authenticate(employeeList, 222, "wrongPass");
        assertNull(result);
    }

    @Test
    void authenticate_invalidId_shouldReturnNull() {
        Employee result = LoginManager.authenticate(employeeList, 999, "passIT");
        assertNull(result);
    }

    @Test
    void isHR_trueIfDepartmentIsHR() {
        assertTrue(LoginManager.isHR(hrEmployee));
    }

    @Test
    void isHR_falseIfNotHRDepartmentOrPosition() {
        assertFalse(LoginManager.isHR(nonHrEmployee));
    }

    @Test
    void displayUserSummary_shouldPrintDetails() {
        assertDoesNotThrow(() -> LoginManager.displayUserSummary(nonHrEmployee));
    }
}
