package data;

import Models.Employee;
import Models.LeaveRequest;
import org.junit.jupiter.api.*;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class FileHandlerTest {

    private final String EMPLOYEE_FILE = "employees.txt";
    private final String LEAVE_FILE = "leaves.txt";

    private ArrayList<Employee> sampleEmployees;
    private ArrayList<LeaveRequest> sampleLeaves;

    @BeforeEach
    void setUp() {
        sampleEmployees = new ArrayList<>();
        Employee emp1 = new Employee(1, "Alice", "IT", "Developer", 5000.0, 30, 100.0, "pass123");
        Employee emp2 = new Employee(2, "Bob", "HR", "Manager", 6000.0, 25, 90.0, "pass456");
        sampleEmployees.add(emp1);
        sampleEmployees.add(emp2);

        sampleLeaves = new ArrayList<>();
        sampleLeaves.add(new LeaveRequest(emp1, LocalDate.of(2025, 5, 10), LocalDate.of(2025, 5, 15)));
        LeaveRequest lr = new LeaveRequest(emp2, LocalDate.of(2025, 6, 1), LocalDate.of(2025, 6, 3));
        lr.setApproved(true);
        sampleLeaves.add(lr);
    }

    @AfterEach
    void tearDown() {
        try {
            //Files.deleteIfExists(Paths.get(EMPLOYEE_FILE));
            //Files.deleteIfExists(Paths.get(LEAVE_FILE));
        } catch (Exception e) {
            System.out.println("Cleanup failed: " + e.getMessage());
        }
    }

    @Test
    void saveEmployees() {
        FileHandler.saveEmployees(sampleEmployees);
        File file = new File(EMPLOYEE_FILE);
        System.out.println(file.getAbsolutePath());
        assertTrue(file.exists() && file.length() > 0, "Employee file should exist and not be empty");
    }

    @Test
    void loadEmployees() {
        FileHandler.saveEmployees(sampleEmployees);
        ArrayList<Employee> loaded = FileHandler.loadEmployees();

        assertEquals(2, loaded.size());
        assertEquals("Alice", loaded.get(0).getName());
        assertEquals("Bob", loaded.get(1).getName());
    }

    @Test
    void saveLeaves() {
        FileHandler.saveLeaves(sampleLeaves);
        File file = new File(LEAVE_FILE);
        assertTrue(file.exists() && file.length() > 0, "Leave file should exist and not be empty");
    }

    @Test
    void loadLeaves() {
        FileHandler.saveEmployees(sampleEmployees);
        FileHandler.saveLeaves(sampleLeaves);

        ArrayList<Employee> loadedEmployees = FileHandler.loadEmployees();
        ArrayList<LeaveRequest> loadedLeaves = FileHandler.loadLeaves(loadedEmployees);

        assertEquals(2, loadedLeaves.size());
        assertEquals(LocalDate.of(2025, 5, 10), loadedLeaves.get(0).getStartDate());
        assertTrue(loadedLeaves.get(1).isApproved());
    }

    // Duplicate tests (optional): for method aliasing or renamed methods
    @Test
    void testSaveEmployees() {
        saveEmployees();
    }

    @Test
    void testLoadEmployees() {
        loadEmployees();
    }

    @Test
    void testSaveLeaves() {
        saveLeaves();
    }

    @Test
    void testLoadLeaves() {
        loadLeaves();
    }
}
