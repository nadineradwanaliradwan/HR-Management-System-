package data;



import Models.Employee;

import java.util.ArrayList;

public class LoginManager {

    // Authenticate user based on ID and password
    public static Employee authenticate(ArrayList<Employee> employees, int id, String password) {
        for (Employee emp : employees) {
            System.out.println(emp);

            if (emp.getEmployeeId() == id && emp.getPassword().equals(password)) {
                System.out.println("Login successful! Welcome, " + emp.getName());
                return emp;
            }
        }
        System.out.println("Login failed. Invalid ID or password.");
        return null;
    }

    // Optional: Check if user is HR (based on position or department)
    public static boolean isHR(Employee employee) {
        return employee.getDepartment().equalsIgnoreCase("HR") ||
                employee.getPosition().equalsIgnoreCase("HR");
    }

    // Optional: Login summary
    public static void displayUserSummary(Employee emp) {
        System.out.println("------ User Info ------");
        System.out.println("ID        : " + emp.getEmployeeId());
        System.out.println("Name      : " + emp.getName());
        System.out.println("Department: " + emp.getDepartment());
        System.out.println("Position  : " + emp.getPosition());
        System.out.println("Salary    : $" + emp.getSalary());
        System.out.println("------------------------");
    }
}
