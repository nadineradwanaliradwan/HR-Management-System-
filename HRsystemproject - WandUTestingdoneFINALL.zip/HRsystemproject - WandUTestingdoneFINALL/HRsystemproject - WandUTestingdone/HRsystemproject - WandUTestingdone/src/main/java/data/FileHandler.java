package data;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.ArrayList;

import Models.Employee;
import Models.LeaveRequest;

public class FileHandler {
    private static final String EMPLOYEE_FILE = "D:\\ASU\\Semester 6\\Testing\\Project spring 25\\HRsystemproject - WandUTestingdoneFINALL\\HRsystemproject - WandUTestingdone\\HRsystemproject - WandUTestingdone\\employees.txt";
    private static final String LEAVE_FILE = "D:\\ASU\\Semester 6\\Testing\\Project spring 25\\HRsystemproject - WandUTestingdoneFINALL\\HRsystemproject - WandUTestingdone\\HRsystemproject - WandUTestingdone\\leaves.txt";

    public static void saveEmployees(ArrayList<Employee> employees) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(EMPLOYEE_FILE))) {
            for (Employee emp : employees) {
                writer.println(emp.getEmployeeId() + "," + emp.getName() + "," + emp.getDepartment() + "," +
                        emp.getPosition() + "," + emp.getSalary() + "," + emp.getRemainingLeaveDays() + "," +
                        emp.getPerformanceRating() + "," + emp.getPassword());
            }
        } catch (IOException e) {
            System.out.println("Error saving employees: " + e.getMessage());
        }
    }

    public static ArrayList<Employee> loadEmployees() {
        ArrayList<Employee> employees = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(EMPLOYEE_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 8) {
                    int id = Integer.parseInt(parts[0]);
                    String name = parts[1];
                    String department = parts[2];
                    String position = parts[3];
                    double salary = Double.parseDouble(parts[4]);
                    int leaveDays = Integer.parseInt(parts[5]);
                    double rating = Double.parseDouble(parts[6]);
                    String password = parts[7];

                    Employee emp = new Employee(id, name, department, position, salary, leaveDays, rating, password);
                    employees.add(emp);
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading employees: " + e.getMessage());
        }

        return employees;
    }

    public static void saveLeaves(ArrayList<LeaveRequest> leaves) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(LEAVE_FILE))) {
            for (LeaveRequest leave : leaves) {
                writer.println(leave.getEmployeeId().getEmployeeId() + "," +
                        leave.getStartDate() + "," + leave.getEndDate() + "," + leave.isApproved());
            }
        } catch (IOException e) {
            System.out.println("Error saving leave requests: " + e.getMessage());
        }
    }

    public static ArrayList<LeaveRequest> loadLeaves(ArrayList<Employee> employees) {
        ArrayList<LeaveRequest> leaves = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(LEAVE_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 4) {
                    int empId = Integer.parseInt(parts[0]);
                    LocalDate startDate = LocalDate.parse(parts[1]);
                    LocalDate endDate = LocalDate.parse(parts[2]);
                    boolean approved = Boolean.parseBoolean(parts[3]);

                    Employee emp = null;
                    for (Employee e : employees) {
                        if (e.getEmployeeId() == empId) {
                            emp = e;
                            break;
                        }
                    }

                    if (emp != null) {
                        LeaveRequest leave = new LeaveRequest(emp, startDate, endDate);
                        leave.setApproved(approved);
                        leaves.add(leave);
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading leave requests: " + e.getMessage());
        }

        return leaves;
    }
}