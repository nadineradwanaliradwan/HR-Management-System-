package Controller;


import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Button;

public class HRDashboardController {

    @FXML
    private Button addEmployeeBtn;

    @FXML
    private Button viewEmployeesBtn;

    @FXML
    private Button logoutBtn;

    @FXML
    private void handleAddEmployee() {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/view/add_employee.fxml"));
            Stage stage = new Stage();
            stage.setTitle("Add New Employee");
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleViewEmployees() {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/view/view_employees.fxml"));
            Stage stage = new Stage();
            stage.setTitle("All Employees");
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleLogout() {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/view/login.fxml"));
            Stage stage = (Stage) logoutBtn.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
