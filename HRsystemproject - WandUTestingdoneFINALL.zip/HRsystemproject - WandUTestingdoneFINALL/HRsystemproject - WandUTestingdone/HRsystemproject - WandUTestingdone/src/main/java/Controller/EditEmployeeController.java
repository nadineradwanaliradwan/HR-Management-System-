package Controller;



import data.FileHandler;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import Models.Employee;

import java.util.ArrayList;

public class EditEmployeeController {

    @FXML private TextField idField;
    @FXML private TextField nameField;
    @FXML private TextField deptField;
    @FXML private TextField positionField;
    @FXML private TextField salaryField;

    private Employee selectedEmployee;

    private ObservableList<Employee> employeeList;

    public void setEmployee(Employee emp, ObservableList<Employee> list) {
        this.selectedEmployee = emp;
        this.employeeList = list;

        idField.setText(String.valueOf(emp.getEmployeeId()));
        nameField.setText(emp.getName());
        deptField.setText(emp.getDepartment());
        positionField.setText(emp.getPosition());
        salaryField.setText(String.valueOf(emp.getSalary()));
    }



    @FXML
    private void handleSave() {
        try {
            selectedEmployee.setName(nameField.getText());
            selectedEmployee.setDepartment(deptField.getText());
            selectedEmployee.setPosition(positionField.getText());
            selectedEmployee.setSalary(Double.parseDouble(salaryField.getText()));

            // Update list in memory
            for (int i = 0; i < employeeList.size(); i++) {
                if (employeeList.get(i).getEmployeeId() == selectedEmployee.getEmployeeId()) {
                    employeeList.set(i, selectedEmployee); // Refresh TableView
                    break;
                }
            }

            // Save to file
            FileHandler.saveEmployees(new ArrayList<>(employeeList));

            showAlert("Success", "Employee updated successfully.");

            Stage stage = (Stage) idField.getScene().getWindow();
            stage.close();

        } catch (Exception e) {
            showAlert("Error", "Make sure salary is numeric.");
        }
    }


    private void showAlert(String title, String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
