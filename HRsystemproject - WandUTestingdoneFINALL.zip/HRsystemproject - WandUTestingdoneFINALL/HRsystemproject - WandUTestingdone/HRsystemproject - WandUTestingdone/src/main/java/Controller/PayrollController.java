package Controller;

import Models.Employee;
import Models.Payroll;
import data.FileHandler;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.Optional;

public class PayrollController {

    @FXML private Label nameLabel;
    @FXML private Label salaryLabel;
    @FXML private TextArea summaryArea;


    private Employee employee;
    private ObservableList<Employee> employees;
    private TableView<Employee> tableView;

    public void setEmployee(Employee employee, ObservableList<Employee> employees, TableView<Employee> tableView) {
        this.employee = employee;
        this.employees = employees;
        this.tableView = tableView;
        updateDisplay();
    }

    private void updateDisplay() {
        nameLabel.setText("Employee: " + employee.getName());
        salaryLabel.setText("Salary: $" + employee.getSalary());
    }

    private void saveChanges() {
        ArrayList<Employee> all = FileHandler.loadEmployees();
        for (Employee e : all) {
            if (e.getEmployeeId() == employee.getEmployeeId()) {
                e.setSalary(employee.getSalary());
                break;
            }
        }
        FileHandler.saveEmployees(all);
        if (tableView != null) {
            tableView.refresh();
        }
    }

    @FXML
    private void handleAddBonus() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Add Bonus");
        dialog.setHeaderText("Enter bonus amount:");
        Optional<String> result = dialog.showAndWait();
        result.ifPresent(input -> {
            try {
                double bonus = Double.parseDouble(input);
                Payroll.addBonus(employee, bonus);
                updateDisplay();
                saveChanges();
            } catch (NumberFormatException e) {
                showAlert("Invalid input", "Please enter a valid number.");
            }
        });
    }

    @FXML
    private void handleDeductSalary() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Deduct Salary");
        dialog.setHeaderText("Enter amount to deduct:");
        Optional<String> result = dialog.showAndWait();
        result.ifPresent(input -> {
            try {
                double deduction = Double.parseDouble(input);
                Payroll.deductSalary(employee, deduction);
                updateDisplay();
                saveChanges();
            } catch (NumberFormatException e) {
                showAlert("Invalid input", "Please enter a valid number.");
            }
        });
    }

    @FXML
    private void handleApplyTax() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Apply Tax");
        dialog.setHeaderText("Enter tax percentage (0-100):");
        Optional<String> result = dialog.showAndWait();
        result.ifPresent(input -> {
            try {
                double tax = Double.parseDouble(input);
                Payroll.applyTax(employee, tax);
                updateDisplay();
                saveChanges();
            } catch (NumberFormatException e) {
                showAlert("Invalid input", "Please enter a valid number.");
            }
        });
    }

    @FXML
    private void handlePrintSummary() {
        StringBuilder sb = new StringBuilder();
        sb.append("---- Payroll Summary ----\n");
        sb.append("Employee ID: ").append(employee.getEmployeeId()).append("\n");
        sb.append("Name       : ").append(employee.getName()).append("\n");
        sb.append("Department : ").append(employee.getDepartment()).append("\n");
        sb.append("Position   : ").append(employee.getPosition()).append("\n");
        sb.append("Salary     : $").append(employee.getSalary()).append("\n");
        sb.append("Leave Days : ").append(employee.getRemainingLeaveDays()).append("\n");
        sb.append("Performance: ").append(employee.getPerformanceRating()).append("%\n");
        sb.append("--------------------------\n");

        summaryArea.setText(sb.toString());
    }


    @FXML
    private void handleClose() {
        Stage stage = (Stage) nameLabel.getScene().getWindow();
        stage.close();
    }

    private void showAlert(String title, String msg) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
