package Controller;

import data.FileHandler;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import Models.Employee;

import java.util.ArrayList;

public class AddEmployeeController {

    @FXML private TextField idField;
    @FXML private TextField nameField;
    @FXML private TextField deptField;
    @FXML private TextField positionField;
    @FXML private TextField salaryField;
    @FXML private TextField passwordField;

    @FXML
    private void handleAddEmployee() {
        try {
            int id = Integer.parseInt(idField.getText());
            String name = nameField.getText();
            String dept = deptField.getText();
            String position = positionField.getText();
            double salary = Double.parseDouble(salaryField.getText());
            String password = passwordField.getText();

            if (name.isEmpty() || dept.isEmpty() || position.isEmpty() || password.isEmpty()) {
                showAlert("Validation Error", "All fields are required!");
                return;
            }

            ArrayList<Employee> employees = FileHandler.loadEmployees();
            for (Employee emp : employees) {
                if (emp.getEmployeeId() == id) {
                    showAlert("Error", "Employee with this ID already exists!");
                    return;
                }
            }

            Employee newEmp = new Employee(id, name, dept, position, salary, 30, 100.0, password);
            employees.add(newEmp);
            FileHandler.saveEmployees(employees);
            showAlert("Success", "Employee added successfully!");

            // Close the window
            Stage stage = (Stage) idField.getScene().getWindow();
            stage.close();

        } catch (NumberFormatException e) {
            showAlert("Input Error", "ID and Salary must be numeric.");
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
