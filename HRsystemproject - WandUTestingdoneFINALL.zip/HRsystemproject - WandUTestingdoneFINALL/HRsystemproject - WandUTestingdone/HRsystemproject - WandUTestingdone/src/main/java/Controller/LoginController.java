package Controller;

import java.io.IOException;
import java.util.ArrayList;

import Models.Employee;
import data.FileHandler;
import data.LoginManager;
import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Duration;

public class LoginController {

    @FXML private TextField idField;
    @FXML private PasswordField passwordField;
    @FXML private TextField visiblePasswordField;
    @FXML private CheckBox showPasswordCheck;
    @FXML private Label errorLabel;
    @FXML private VBox formContainer;
    @FXML private Button loginButton;

    private ArrayList<Employee> employees;
    public static Employee loggedInEmployee;

    @FXML
    public void initialize() {
        employees = FileHandler.loadEmployees();
        idField.requestFocus();

        visiblePasswordField.textProperty().bindBidirectional(passwordField.textProperty());

        showPasswordCheck.selectedProperty().addListener((obs, oldVal, newVal) -> {
            visiblePasswordField.setVisible(newVal);
            visiblePasswordField.setManaged(newVal);
            passwordField.setVisible(!newVal);
            passwordField.setManaged(!newVal);
        });

        idField.setOnAction(e -> handleLogin());
        passwordField.setOnAction(e -> handleLogin());
        visiblePasswordField.setOnAction(e -> handleLogin());

        FadeTransition fadeIn = new FadeTransition(Duration.millis(700), formContainer);
        fadeIn.setFromValue(0.0);
        fadeIn.setToValue(1.0);
        fadeIn.play();
    }

    @FXML
    private void handleLogin() {
        try {
            int id = Integer.parseInt(idField.getText().trim());
            String password = passwordField.isVisible()
                    ? passwordField.getText().trim()
                    : visiblePasswordField.getText().trim();

            Employee loggedIn = LoginManager.authenticate(employees, id, password);

            if (loggedIn != null) {
                loggedInEmployee = loggedIn;
                String path = LoginManager.isHR(loggedIn)
                        ? "/view/hr_dashboard.fxml"
                        : "/view/employee_dashboard.fxml";

                FadeTransition fadeOut = new FadeTransition(Duration.millis(500), formContainer);
                fadeOut.setFromValue(1.0);
                fadeOut.setToValue(0.0);
                fadeOut.setOnFinished(event -> loadScene(path));
                fadeOut.play();
            } else {
                errorLabel.setText("Invalid ID or password.");
            }

        } catch (NumberFormatException e) {
            errorLabel.setText("ID must be a number.");
        }
    }

    private void loadScene(String fxmlPath) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource(fxmlPath));
            Scene scene = new Scene(root);
            scene.getStylesheets().add(getClass().getResource("/style.css").toExternalForm());
            Stage stage = (Stage) idField.getScene().getWindow();
            stage.setScene(scene);
        } catch (IOException e) {
            errorLabel.setText("Error loading next screen.");
            e.printStackTrace();
        }
    }
}
