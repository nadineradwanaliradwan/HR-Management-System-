package Controller;

import java.time.LocalDate;
import java.util.ArrayList;

import Models.Employee;
import Models.LeaveManagement;
import Models.LeaveRequest;
import Models.EmployeeService;
import Models.LeaveService;
import data.FileHandler;
import javafx.beans.binding.Bindings;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;

public class EmployeeDashboardController {

    @FXML private Label welcomeLabel;
    @FXML private Label nameLabel;
    @FXML private Label idLabel;
    @FXML private Label deptLabel;
    @FXML private Label positionLabel;
    @FXML private Label salaryLabel;
    @FXML private Label leaveDaysLabel;
    @FXML private Label ratingLabel;

    @FXML private DatePicker startDatePicker;
    @FXML private DatePicker endDatePicker;
    @FXML private Button logoutBtn;

    @FXML private TableView<LeaveRequest> leaveTable;
    @FXML private TableColumn<LeaveRequest, String> startCol;
    @FXML private TableColumn<LeaveRequest, String> endCol;
    @FXML private TableColumn<LeaveRequest, String> statusCol;
    @FXML private TableColumn<LeaveRequest, Void> deleteCol;

    private Employee employee;
    private ObservableList<LeaveRequest> myLeaves;
    private  EmployeeService employeeService;
    private  LeaveService leaveService;
    @FXML
    private void initialize() {
        employeeService = new EmployeeService(new data.FileHandler());
        leaveService=  new LeaveService(new data.FileHandler());
        this.employee = LoginController.loggedInEmployee;
        welcomeLabel.setText("Welcome, " + employee.getName());
        updateDashboard();
        loadLeaveRequests();
    }

    private void updateDashboard() {
        nameLabel.setText(employee.getName());
        idLabel.setText(String.valueOf(employee.getEmployeeId()));
        deptLabel.setText(employee.getDepartment());
        positionLabel.setText(employee.getPosition());
        salaryLabel.setText(String.format("$%.2f", employee.getSalary()));
        leaveDaysLabel.setText(String.valueOf(employee.getRemainingLeaveDays()));
        ratingLabel.setText(String.format("%.1f%%", employee.getPerformanceRating()));
    }

    private void loadLeaveRequests() {
        ArrayList<Employee> allEmployees = new ArrayList<>(employeeService.loadAllEmployees());
        myLeaves = FXCollections.observableArrayList(
                leaveService.loadEmployeeLeaves(employee.getEmployeeId(), allEmployees)
        );

        startCol.setCellValueFactory(c -> Bindings.createStringBinding(() -> c.getValue().getStartDate().toString()));
        endCol.setCellValueFactory(c -> Bindings.createStringBinding(() -> c.getValue().getEndDate().toString()));
        statusCol.setCellValueFactory(c -> Bindings.createStringBinding(() -> c.getValue().isApproved() ? "Approved" : "Pending"));

        statusCol.setCellFactory(column -> new TableCell<>() {
            @Override
            protected void updateItem(String status, boolean empty) {
                super.updateItem(status, empty);
                if (empty || status == null) {
                    setText(null);
                    setStyle("");
                } else {
                    setText(status);
                    setStyle("-fx-text-fill: " + (status.equals("Approved") ? "green" : "orange"));
                }
            }
        });

        addDeleteButtonToTable();
        leaveTable.setItems(myLeaves);
    }


    private void addDeleteButtonToTable() {
        deleteCol.setCellFactory(col -> new TableCell<>() {
            private final Button deleteBtn = new Button("Delete");

            {
                deleteBtn.setOnAction(e -> {
                    LeaveRequest leave = getTableView().getItems().get(getIndex());

                    if (!leave.isApproved()) {
                        try {
                            leaveService.deleteLeaveRequest(
                                    leave.getEmployeeId().getEmployeeId(),
                                    leave.getStartDate(),
                                    leave.getEndDate()
                            );
                            myLeaves.remove(leave);
                            leaveTable.refresh();
                            showAlert("Deleted", "Leave request has been removed.");
                        } catch (IllegalArgumentException ex) {
                            showAlert("Error", ex.getMessage());
                        }
                    }
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    LeaveRequest leave = getTableView().getItems().get(getIndex());
                    deleteBtn.setDisable(leave.isApproved());
                    setGraphic(deleteBtn);
                }
            }
        });
    }

    @FXML
    private void handleSubmitLeave() {
        LocalDate start = startDatePicker.getValue();
        LocalDate end = endDatePicker.getValue();

        try {
            leaveService.submitLeaveRequest(employee, start, end);
            myLeaves.add(new LeaveRequest(employee, start, end));
            leaveTable.refresh();
            showAlert("Success", "Leave request submitted!");
        } catch (IllegalArgumentException e) {
            showAlert("Validation Failed", e.getMessage());
        }
    }

    @FXML
    private void handleLogout() {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/view/login.fxml"));
            Scene scene = new Scene(root);
            scene.getStylesheets().add(getClass().getResource("/style.css").toExternalForm());
            Stage stage = (Stage) logoutBtn.getScene().getWindow();
            stage.setScene(scene);
        } catch (Exception ex) {
            ex.printStackTrace();
            showAlert("Error", "Could not load login screen.");
        }
    }

    private void showAlert(String title, String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }

    @FXML
    private void handleToggleTheme() {
        Scene scene = logoutBtn.getScene();
        if (scene.getRoot().getStyleClass().contains("dark")) {
            scene.getRoot().getStyleClass().remove("dark");
        } else {
            scene.getRoot().getStyleClass().add("dark");
        }
    }
}
