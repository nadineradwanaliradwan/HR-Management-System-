package Controller;

import Models.Employee;
import Models.LeaveRequest;
import Models.PerformanceEvaluation;
import data.FileHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextInputDialog;
import javafx.stage.Stage;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Optional;
import javafx.collections.ObservableList;
import javafx.scene.control.TableView;

public class PerformanceController {

    @FXML private Label nameLabel;
    @FXML private Label ratingLabel;
    @FXML private Label daysLabel;
    private ObservableList<Employee> employees;
    private TableView<Employee> tableView;

    private Employee employee;

    public void setEmployee(Employee employee, ObservableList<Employee> employees, TableView<Employee> tableView) {
        this.employee = employee;
        this.employees = employees;
        this.tableView = tableView;
        updateDisplay();
    }
    private void updateDisplay() {
        nameLabel.setText("Employee: " + employee.getName());
        ratingLabel.setText("Performance Rating: " + employee.getPerformanceRating());
        daysLabel.setText("Remaining Leave Days: " + employee.getRemainingLeaveDays());

    }

    private void saveChanges() {
        ArrayList<Employee> all = FileHandler.loadEmployees();
        for (Employee e : all) {
            if (e.getEmployeeId() == employee.getEmployeeId()) {
                e.setPerformanceRating(employee.getPerformanceRating());
                break;
            }
        }
        FileHandler.saveEmployees(all);
        if (tableView != null) {
            tableView.refresh();
        }
    }

    @FXML
    private void handleRecalculate() {


        PerformanceEvaluation.calculatePerformanceRate(employee,
                employee.getRemainingLeaveDays());

        ratingLabel.setText("Performance Rating: " + employee.getPerformanceRating());
        saveChanges();
    }

    @FXML
    private void handleManualSet() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Manual Rating");
        dialog.setHeaderText("Set performance rating (0 to 100):");
        Optional<String> result = dialog.showAndWait();
        result.ifPresent(input -> {
            try {
                double rating = Double.parseDouble(input);
                PerformanceEvaluation.setPerformanceManually(employee, rating);
                updateDisplay();
                saveChanges();
            } catch (NumberFormatException e) {
                System.out.println("Invalid number.");
            }
        });
    }

    @FXML
    private void handleBoost() {
        PerformanceEvaluation.boostPerformance(employee, 10);
        updateDisplay();
        saveChanges();
    }

    @FXML
    private void handlePenalty() {
        PerformanceEvaluation.penalizePerformance(employee, 10);
        updateDisplay();
        saveChanges();
    }

    @FXML
    private void handleDisplayReport() {
        PerformanceEvaluation.displayPerformance(employee);
    }

    @FXML
    private void handleClose() {
        Stage stage = (Stage) nameLabel.getScene().getWindow();
        stage.close();
    }
}
