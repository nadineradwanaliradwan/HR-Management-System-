package Controller;

import Models.Employee;
import Models.LeaveManagement;
import Models.LeaveRequest;
import data.FileHandler;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.util.ArrayList;

public class LeaveManagementController {

    @FXML private TableView<LeaveRequest> leaveTable;
    @FXML private TableColumn<LeaveRequest, String> startCol;
    @FXML private TableColumn<LeaveRequest, String> endCol;
    @FXML private TableColumn<LeaveRequest, String> statusCol;
    @FXML private TableColumn<LeaveRequest, Void> approveCol;

    private Employee employee;
    private ObservableList<Employee> employeeList;
    private TableView<Employee> mainEmployeeTable;
    private ObservableList<LeaveRequest> leaveRequests;

    public void setEmployee(Employee emp, ObservableList<Employee> employeeList, TableView<Employee> mainTable) {
        this.employee = emp;
        this.employeeList = employeeList;
        this.mainEmployeeTable = mainTable;
        loadLeaveRequests();
    }

    private void loadLeaveRequests() {
        ArrayList<Employee> allEmployees = FileHandler.loadEmployees();
        ArrayList<LeaveRequest> allLeaves = FileHandler.loadLeaves(allEmployees);

        leaveRequests = FXCollections.observableArrayList();

        for (LeaveRequest leave : allLeaves) {
            if (leave.getEmployeeId().getEmployeeId() == employee.getEmployeeId()) {
                leaveRequests.add(leave);
            }
        }

        startCol.setCellValueFactory(cell -> javafx.beans.binding.Bindings.createStringBinding(() ->
                cell.getValue().getStartDate().toString()));
        endCol.setCellValueFactory(cell -> javafx.beans.binding.Bindings.createStringBinding(() ->
                cell.getValue().getEndDate().toString()));
        statusCol.setCellValueFactory(cell -> javafx.beans.binding.Bindings.createStringBinding(() ->
                leaveStatusText(cell.getValue().isApproved())));

        addApproveButtonToTable();

        leaveTable.setItems(leaveRequests);
    }

    private void addApproveButtonToTable() {
        approveCol.setCellFactory(col -> new TableCell<>() {
            private final Button btn = new Button("Approve");

            {
                btn.setOnAction(e -> {
                    LeaveRequest leave = getTableView().getItems().get(getIndex());
                    if (!leave.isApproved()) {
                        leave.setApproved(true);
                        LeaveManagement.updateLeaveBalance(leave, leave.getEmployeeId());

                        FileHandler.saveLeaves(new ArrayList<>(leaveRequests));
                        FileHandler.saveEmployees(new ArrayList<>(employeeList));
                        mainEmployeeTable.refresh(); // Reflect changes on main page
                        leaveTable.refresh();        // Reflect status update
                    }
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty || getTableView().getItems().get(getIndex()).isApproved() ? null : btn);
            }
        });
    }

    private String leaveStatusText(boolean approved) {
        return approved ? "Approved" : "Pending";
    }

    @FXML
    private void handleClose() {
        Stage stage = (Stage) leaveTable.getScene().getWindow();
        stage.close();
    }
}
