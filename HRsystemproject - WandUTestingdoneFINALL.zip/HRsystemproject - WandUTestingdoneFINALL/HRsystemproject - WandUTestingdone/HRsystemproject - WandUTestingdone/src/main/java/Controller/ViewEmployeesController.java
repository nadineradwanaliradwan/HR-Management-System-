package Controller;

import data.FileHandler;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import Models.Employee;
import javafx.stage.Stage;

import java.util.ArrayList;

public class ViewEmployeesController {

    @FXML private TableView<Employee> employeeTable;
    @FXML private TableColumn<Employee, Integer> idCol;
    @FXML private TableColumn<Employee, String> nameCol;
    @FXML private TableColumn<Employee, String> deptCol;
    @FXML private TableColumn<Employee, String> posCol;
    @FXML private TableColumn<Employee, Double> salaryCol;
    @FXML private TableColumn<Employee, Integer> leaveCol;
    @FXML private TableColumn<Employee, Double> rateCol;
    @FXML private TableColumn<Employee, Void> editCol;
    @FXML private TableColumn<Employee, Void> deleteCol;
    @FXML private TableColumn<Employee, Void> performanceCol;
    @FXML private TableColumn<Employee, Void> payrollCol;
    @FXML private TableColumn<Employee, Void> leaveManage;

    private ObservableList<Employee> data;

    @FXML
    public void initialize() {
        ArrayList<Employee> list = FileHandler.loadEmployees();
        data = FXCollections.observableArrayList(list);

        idCol.setCellValueFactory(new PropertyValueFactory<>("employeeId"));
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        deptCol.setCellValueFactory(new PropertyValueFactory<>("department"));
        posCol.setCellValueFactory(new PropertyValueFactory<>("position"));
        salaryCol.setCellValueFactory(new PropertyValueFactory<>("salary"));
        leaveCol.setCellValueFactory(new PropertyValueFactory<>("remainingLeaveDays"));
        rateCol.setCellValueFactory(new PropertyValueFactory<>("performanceRating"));

        addEditButtonToTable();
        addDeleteButtonToTable();
        addActionButtons();

        employeeTable.setItems(data);
    }

    private void addEditButtonToTable() {
        editCol.setCellFactory(col -> new TableCell<>() {
            private final Button editBtn = new Button("Edit");

            {
                editBtn.setOnAction(e -> {
                    Employee emp = getTableView().getItems().get(getIndex());
                    try {
                        FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/edit_employee.fxml"));
                        Parent root = loader.load();
                        EditEmployeeController controller = loader.getController();
                        controller.setEmployee(emp, employeeTable.getItems());

                        Stage stage = new Stage();
                        stage.setTitle("Edit Employee");
                        stage.setScene(new Scene(root));
                        stage.show();
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : new HBox(editBtn));
            }
        });
    }

    private void addDeleteButtonToTable() {
        deleteCol.setCellFactory(col -> new TableCell<>() {
            private final Button delBtn = new Button("Delete");

            {
                delBtn.setOnAction(e -> {
                    Employee emp = getTableView().getItems().get(getIndex());
                    data.remove(emp);
                    FileHandler.saveEmployees(new ArrayList<>(data));
                    showAlert("Deleted", "Employee " + emp.getName() + " removed.");
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : new HBox(delBtn));
            }
        });
    }

    private void addActionButtons() {
        performanceCol.setCellFactory(col -> new TableCell<>() {
            private final Button btn = new Button("Performance");
            {
                btn.setOnAction(e -> {
                    Employee emp = getTableView().getItems().get(getIndex());
                    openWindow("/view/performance.fxml", "Performance", emp);
                });
            }
            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : new HBox(btn));
            }
        });

        payrollCol.setCellFactory(col -> new TableCell<>() {
            private final Button btn = new Button("Payroll");
            {
                btn.setOnAction(e -> {
                    Employee emp = getTableView().getItems().get(getIndex());
                    openWindow("/view/payroll.fxml", "Payroll", emp);
                });
            }
            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : new HBox(btn));
            }
        });

        leaveManage.setCellFactory(col -> new TableCell<>() {
            private final Button btn = new Button("Leave");
            {
                btn.setOnAction(e -> {
                    Employee emp = getTableView().getItems().get(getIndex());
                    openWindow("/view/leave_management.fxml", "Leave Management", emp);
                });
            }
            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : new HBox(btn));
            }
        });
    }
    private void openWindow(String fxml, String title, Employee emp) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxml));
            Parent root = loader.load();

            // Pass employee + references to table if needed
            Object controller = loader.getController();
            if (controller instanceof PerformanceController) {
                ((PerformanceController) controller).setEmployee(emp, data, employeeTable);
            } else if (controller instanceof PayrollController) {
                ((PayrollController) controller).setEmployee(emp,data, employeeTable);
            } else if (controller instanceof LeaveManagementController) {
                ((LeaveManagementController) controller).setEmployee(emp,data, employeeTable);
            }

            Stage stage = new Stage();
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @FXML
    private void handleClose() {
        employeeTable.getScene().getWindow().hide();
    }

    private void showAlert(String title, String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
