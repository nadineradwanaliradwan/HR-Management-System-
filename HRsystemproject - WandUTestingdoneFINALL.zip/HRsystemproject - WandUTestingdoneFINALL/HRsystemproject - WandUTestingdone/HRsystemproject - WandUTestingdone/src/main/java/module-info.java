module hr.hrsystemproject {
    requires javafx.controls;
    requires javafx.fxml;

    opens Models to javafx.base, javafx.fxml;
    opens hr.hrsystemproject to javafx.fxml;
    exports hr.hrsystemproject;
    exports Controller;
    opens Controller to javafx.fxml;
    exports data;
    opens data to javafx.fxml;
}