package Models;

import data.FileHandler;
import Models.Employee;
import Models.LeaveRequest;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class LeaveService {

    private final FileHandler fileHandler;

    public LeaveService(FileHandler fileHandler) {
        this.fileHandler = fileHandler;
    }

    public List<LeaveRequest> loadEmployeeLeaves(int employeeId, ArrayList<Employee> allEmployees) {
        ArrayList<LeaveRequest> allLeaves = fileHandler.loadLeaves(allEmployees);
        return allLeaves.stream()
                .filter(leave -> leave.getEmployeeId().getEmployeeId() == employeeId)
                .collect(Collectors.toList());
    }

    public void submitLeaveRequest(Employee employee, LocalDate start, LocalDate end) throws IllegalArgumentException {
        LeaveRequest request = new LeaveRequest(employee, start, end);

        if (!validateLeaveRequest(employee, request)) {
            throw new IllegalArgumentException("Leave request is invalid. Check your date range or leave balance.");
        }

        ArrayList<LeaveRequest> allLeaves = fileHandler.loadLeaves(fileHandler.loadEmployees());
        allLeaves.add(request);
        fileHandler.saveLeaves(allLeaves);
    }

    public void deleteLeaveRequest(int employeeId, LocalDate startDate, LocalDate endDate) throws IllegalArgumentException {
        ArrayList<Employee> allEmployees = fileHandler.loadEmployees();
        ArrayList<LeaveRequest> allLeaves = fileHandler.loadLeaves(allEmployees);

        LeaveRequest toDelete = null;
        for (LeaveRequest leave : allLeaves) {
            if (leave.getEmployeeId().getEmployeeId() == employeeId &&
                    leave.getStartDate().equals(startDate) &&
                    leave.getEndDate().equals(endDate) &&
                    !leave.isApproved()) {
                toDelete = leave;
                break;
            }
        }

        if (toDelete == null) {
            throw new IllegalArgumentException("Cannot delete: Leave request not found or already approved.");
        }

        allLeaves.remove(toDelete);
        fileHandler.saveLeaves(allLeaves);
    }

    public void approveLeaveRequest(LeaveRequest leave, ArrayList<LeaveRequest> allLeaves, ArrayList<Employee> allEmployees) throws IllegalArgumentException {
        if (leave.isApproved()) {
            throw new IllegalArgumentException("Leave request is already approved.");
        }

        leave.setApproved(true);
        updateLeaveBalance(leave, leave.getEmployeeId());
        fileHandler.saveLeaves(allLeaves);
        fileHandler.saveEmployees(allEmployees);
    }

    private boolean validateLeaveRequest(Employee employee, LeaveRequest leave) {
        LocalDate today = LocalDate.now();
        LocalDate start = leave.getStartDate();
        LocalDate end = leave.getEndDate();

        if (start.isBefore(today)) {
            return false;
        }

        if (!end.isAfter(start)) {
            return false;
        }

        int daysRequested = calculateLeaveDays(start, end);
        return employee.getRemainingLeaveDays() >= daysRequested;
    }

    private void updateLeaveBalance(LeaveRequest leave, Employee employee) {
        int daysTaken = calculateLeaveDays(leave.getStartDate(), leave.getEndDate());
        if (employee.getRemainingLeaveDays() >= daysTaken) {
            int newBalance = employee.getRemainingLeaveDays() - daysTaken;
            employee.setRemainingLeaveDays(newBalance);
        } else {
            throw new IllegalArgumentException("Days requested exceed available balance.");
        }
    }

    private int calculateLeaveDays(LocalDate start, LocalDate end) {
        return (int) (end.toEpochDay() - start.toEpochDay()) + 1;
    }
}