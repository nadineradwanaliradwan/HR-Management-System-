package Models;


import java.time.LocalDate;

public class LeaveRequest {
    private Employee employeeId;
    private LocalDate startDate;
    private LocalDate endDate;
    private boolean isApproved;

    public LeaveRequest(Employee employeeId, LocalDate startDate, LocalDate endDate) {
        this.employeeId = employeeId;
        this.startDate = startDate;
        this.endDate = endDate;
        this.isApproved = false;
    }


    public Employee getEmployeeId() {
        return employeeId;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public boolean isApproved() {
        return isApproved;
    }

    public void setApproved(boolean approved) {
        isApproved = approved;
    }


}
