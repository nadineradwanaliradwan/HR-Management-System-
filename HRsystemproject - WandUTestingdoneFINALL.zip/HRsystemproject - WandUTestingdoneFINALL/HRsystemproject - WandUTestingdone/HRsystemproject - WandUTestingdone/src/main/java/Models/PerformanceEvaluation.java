package Models;


import java.time.LocalDate;

public class PerformanceEvaluation {

    // Automatically calculate performance based on leave usage
    public static void calculatePerformanceRate(Employee employee, int remainingLeaveDays) {
        int totalLeaveDaysUsed = 30 - remainingLeaveDays;

        double performance = 100.0;

        if (totalLeaveDaysUsed > 10 && totalLeaveDaysUsed <= 20) {
            performance -= 10;
        } else if (totalLeaveDaysUsed > 20) {
            performance -= 20;
        }

        employee.setPerformanceRating(Math.max(0, performance));

        System.out.println("Performance updated for " + employee.getName() + ": " + employee.getPerformanceRating() + "%");
    }

    // Manually set performance (e.g. based on a manager's rating)
    public static void setPerformanceManually(Employee employee, double rating) {
        if (rating < 0 || rating > 100) {
            System.out.println("Invalid performance rating. Must be between 0 and 100.");
            return;
        }

        employee.setPerformanceRating(rating);
        System.out.println("Manual performance set for " + employee.getName() + ": " + rating + "%");
    }

    // Boost performance based on achievements or bonus
    public static void boostPerformance(Employee employee, double boostAmount) {
        double newRating = employee.getPerformanceRating() + boostAmount;

        if (newRating > 100) newRating = 100;

        employee.setPerformanceRating(newRating);
        System.out.println("Boosted performance for " + employee.getName() + " to " + newRating + "%");
    }

    // Penalize performance for policy violations or long leaves
    public static void penalizePerformance(Employee employee, double penaltyAmount) {
        double newRating = employee.getPerformanceRating() - penaltyAmount;

        if (newRating < 0) newRating = 0;

        employee.setPerformanceRating(newRating);
        System.out.println("Penalized performance for " + employee.getName() + " to " + newRating + "%");
    }

    // Display performance summary
    public static void displayPerformance(Employee employee) {
        System.out.println("---- Performance Report ----");
        System.out.println("Employee ID   : " + employee.getEmployeeId());
        System.out.println("Name          : " + employee.getName());
        System.out.println("Rating        : " + employee.getPerformanceRating() + "%");
        System.out.println("-----------------------------\n");
    }
}
