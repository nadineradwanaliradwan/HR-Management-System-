package Models;

import Models.Employee;

public class PerformanceService {

    public void calculatePerformanceRate(Employee employee, int remainingLeaveDays) throws IllegalArgumentException {
        if (remainingLeaveDays < 0) {
            throw new IllegalArgumentException("Remaining leave days cannot be negative.");
        }
        double rating = 100 - (remainingLeaveDays * 2.0);
        if (rating < 0) rating = 0;
        if (rating > 100) rating = 100;
        employee.setPerformanceRating(rating);
    }

    public void setPerformanceManually(Employee employee, double rating) throws IllegalArgumentException {
        if (rating < 0 || rating > 100) {
            throw new IllegalArgumentException("Performance rating must be between 0 and 100.");
        }
        employee.setPerformanceRating(rating);
    }

    public void boostPerformance(Employee employee, double boost) throws IllegalArgumentException {
        if (boost < 0) {
            throw new IllegalArgumentException("Boost amount cannot be negative.");
        }
        double newRating = employee.getPerformanceRating() + boost;
        if (newRating > 100) newRating = 100;
        employee.setPerformanceRating(newRating);
    }

    public void penalizePerformance(Employee employee, double penalty) throws IllegalArgumentException {
        if (penalty < 0) {
            throw new IllegalArgumentException("Penalty amount cannot be negative.");
        }
        double newRating = employee.getPerformanceRating() - penalty;
        if (newRating < 0) newRating = 0;
        employee.setPerformanceRating(newRating);
    }

    public String generatePerformanceReport(Employee employee) {
        StringBuilder sb = new StringBuilder();
        sb.append("---- Performance Report ----\n");
        sb.append("Employee ID: ").append(employee.getEmployeeId()).append("\n");
        sb.append("Name       : ").append(employee.getName()).append("\n");
        sb.append("Rating     : ").append(employee.getPerformanceRating()).append("%\n");
        sb.append("----------------------------\n");
        return sb.toString();
    }
}