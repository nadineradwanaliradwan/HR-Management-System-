package Models;


import java.time.LocalDate;
import java.time.format.DateTimeParseException;

public class LeaveManagement {

    // Check if the leave request is valid based on employee's remaining leave days
    public static boolean validateLeaveRequest(Employee employee, LeaveRequest leave) {
        LocalDate today = LocalDate.now();
        LocalDate start = leave.getStartDate();
        LocalDate end = leave.getEndDate();

        // Check if start date is before today
        if (start.isBefore(today)) {
            System.out.println("Start date must be in the future.");
            return false;
        }

        // Check if end date is before or equal to start
        if (!end.isAfter(start)) {
            System.out.println("End date must be after start date.");
            return false;
        }

        // Calculate requested days
        int daysRequested = calculateLeaveDays(start, end);

        // Check if the employee has enough leave balance
        if (employee.getRemainingLeaveDays() < daysRequested) {
            System.out.println("Insufficient leave balance for " + employee.getName());
            return false;
        }

        return true;
    }


    // Update leave balance and performance
    public static void updateLeaveBalance(LeaveRequest leave, Employee employee) {
        int daysTaken = calculateLeaveDays(leave.getStartDate(), leave.getEndDate());

        if (employee.getRemainingLeaveDays() >= daysTaken) {
            int newBalance = employee.getRemainingLeaveDays() - daysTaken;
            employee.setRemainingLeaveDays(newBalance);

            System.out.println("Leave updated. " + employee.getName() + " now has " + newBalance + " leave days left.");



        } else {
            System.out.println("Leave balance not updated. Days requested exceed available balance.");
        }
    }

    // Calculate the number of leave days (inclusive)
    public static int calculateLeaveDays(LocalDate start, LocalDate end) {
        try {

            return (int) (end.toEpochDay() - start.toEpochDay()) + 1;
        } catch (DateTimeParseException e) {
            System.out.println("Invalid date format. Use YYYY-MM-DD.");
            return -1;
        }
    }

    // Display leave request summary
    public static void displayLeaveRequest(LeaveRequest leave) {
        System.out.println("----- Leave Request -----");
        System.out.println("Employee ID : " + leave.getEmployeeId());
        System.out.println("From        : " + leave.getStartDate());
        System.out.println("To          : " + leave.getEndDate());
        System.out.println("Status      : " + (leave.isApproved() ? "Approved" : "Pending/Rejected"));
        System.out.println("--------------------------\n");
    }
}
