package Models;


public class Payroll {

    // Deduct an amount from the employee's salary
    public static void deductSalary(Employee employee, double amount) {
        if (amount < 0) {
            System.out.println("Deduction amount cannot be negative.");
            return;
        }

        double newSalary = employee.getSalary() - amount;

        if (newSalary < 0) {
            System.out.println("Deduction too high! Salary would go below zero.");
            employee.setSalary(0);
        } else {
            employee.setSalary(newSalary);
        }

        System.out.println("New salary for " + employee.getName() + ": $" + employee.getSalary());
    }

    // Add a bonus to the employee's salary
    public static void addBonus(Employee employee, double bonus) {
        if (bonus < 0) {
            System.out.println("Bonus cannot be negative.");
            return;
        }

        employee.setSalary(employee.getSalary() + bonus);
        System.out.println("Bonus added. New salary for " + employee.getName() + ": $" + employee.getSalary());
    }

    // Display payroll summary for an employee
    public static void printPayrollSummary(Employee employee) {
        System.out.println("---- Payroll Summary ----");
        System.out.println("Employee ID: " + employee.getEmployeeId());
        System.out.println("Name       : " + employee.getName());
        System.out.println("Department : " + employee.getDepartment());
        System.out.println("Position   : " + employee.getPosition());
        System.out.println("Salary     : $" + employee.getSalary());
        System.out.println("Leave Days : " + employee.getRemainingLeaveDays());
        System.out.println("Performance: " + employee.getPerformanceRating() + "%");
        System.out.println("--------------------------\n");
    }

    // Optional: Apply a tax deduction percentage
    public static void applyTax(Employee employee, double taxPercent) {
        if (taxPercent < 0 || taxPercent > 100) {
            System.out.println("Invalid tax percentage.");
            return;
        }

        double taxAmount = employee.getSalary() * (taxPercent / 100);
        deductSalary(employee, taxAmount);
        System.out.println("Applied tax of " + taxPercent + "%. Tax amount: $" + taxAmount);
    }
}
