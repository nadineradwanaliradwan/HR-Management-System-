package Models;

import data.FileHandler;
import Models.Employee;
import java.util.ArrayList;
import java.util.List;

public class EmployeeService {

    private final FileHandler fileHandler;

    public EmployeeService(FileHandler fileHandler) {
        this.fileHandler = fileHandler;
    }

    public void addEmployee(int id, String name, String dept, String position, double salary, String password) throws IllegalArgumentException {
        if (name == null || name.isEmpty() || dept == null || dept.isEmpty() ||
                position == null || position.isEmpty() || password == null || password.isEmpty()) {
            throw new IllegalArgumentException("All fields are required!");
        }

        ArrayList<Employee> employees = fileHandler.loadEmployees();
        for (Employee emp : employees) {
            if (emp.getEmployeeId() == id) {
                throw new IllegalArgumentException("Employee with this ID already exists!");
            }
        }

        Employee newEmp = new Employee(id, name, dept, position, salary, 30, 100.0, password);
        employees.add(newEmp);
        fileHandler.saveEmployees(employees);
    }

    public void updateEmployee(int id, String name, String dept, String position, double salary, ArrayList<Employee> employees) throws IllegalArgumentException {
        boolean employeeFound = false;
        for (int i = 0; i < employees.size(); i++) {
            if (employees.get(i).getEmployeeId() == id) {
                Employee updatedEmployee = employees.get(i);
                updatedEmployee.setName(name);
                updatedEmployee.setDepartment(dept);
                updatedEmployee.setPosition(position);
                updatedEmployee.setSalary(salary);
                updatedEmployee.setPerformanceRating(employees.get(i).getPerformanceRating()); // Preserve existing rating
                employees.set(i, updatedEmployee);
                employeeFound = true;
                break;
            }
        }

        if (!employeeFound) {
            throw new IllegalArgumentException("Employee with ID " + id + " not found!");
        }

        fileHandler.saveEmployees(employees);
    }

    public List<Employee> loadAllEmployees() {
        return fileHandler.loadEmployees();
    }

    public void deleteEmployee(int employeeId, ArrayList<Employee> employees) throws IllegalArgumentException {
        boolean employeeFound = false;
        for (int i = 0; i < employees.size(); i++) {
            if (employees.get(i).getEmployeeId() == employeeId) {
                employees.remove(i);
                employeeFound = true;
                break;
            }
        }

        if (!employeeFound) {
            throw new IllegalArgumentException("Employee with ID " + employeeId + " not found!");
        }

        fileHandler.saveEmployees(employees);
    }

    public void updateEmployeeSalary(Employee employee, ArrayList<Employee> employees) throws IllegalArgumentException {
        updateEmployee(
                employee.getEmployeeId(),
                employee.getName(),
                employee.getDepartment(),
                employee.getPosition(),
                employee.getSalary(),
                employees
        );
    }

    public void updateEmployeePerformanceRating(Employee employee, ArrayList<Employee> employees) throws IllegalArgumentException {
        updateEmployee(
                employee.getEmployeeId(),
                employee.getName(),
                employee.getDepartment(),
                employee.getPosition(),
                employee.getSalary(),
                employees
        );
    }
}