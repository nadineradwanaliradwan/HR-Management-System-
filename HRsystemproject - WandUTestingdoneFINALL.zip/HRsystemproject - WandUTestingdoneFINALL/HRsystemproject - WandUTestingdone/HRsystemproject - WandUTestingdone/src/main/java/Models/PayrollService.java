package Models;

import Models.Employee;

public class PayrollService {

    public void addBonus(Employee employee, double bonus) throws IllegalArgumentException {
        if (bonus < 0) {
            throw new IllegalArgumentException("Bonus amount cannot be negative.");
        }
        employee.setSalary(employee.getSalary() + bonus);
    }

    public void deductSalary(Employee employee, double deduction) throws IllegalArgumentException {
        if (deduction < 0) {
            throw new IllegalArgumentException("Deduction amount cannot be negative.");
        }
        double newSalary = employee.getSalary() - deduction;
        if (newSalary < 0) {
            throw new IllegalArgumentException("Deduction would result in a negative salary.");
        }
        employee.setSalary(newSalary);
    }

    public void applyTax(Employee employee, double taxPercentage) throws IllegalArgumentException {
        if (taxPercentage < 0 || taxPercentage > 100) {
            throw new IllegalArgumentException("Tax percentage must be between 0 and 100.");
        }
        double taxAmount = employee.getSalary() * (taxPercentage / 100);
        employee.setSalary(employee.getSalary() - taxAmount);
    }

    public static String generatePayrollSummary(Employee employee) {
        StringBuilder sb = new StringBuilder();
        sb.append("---- Payroll Summary ----\n");
        sb.append("Employee ID: ").append(employee.getEmployeeId()).append("\n");
        sb.append("Name       : ").append(employee.getName()).append("\n");
        sb.append("Department : ").append(employee.getDepartment()).append("\n");
        sb.append("Position   : ").append(employee.getPosition()).append("\n");
        sb.append("Salary     : $").append(employee.getSalary()).append("\n");
        sb.append("Leave Days : ").append(employee.getRemainingLeaveDays()).append("\n");
        sb.append("Performance: ").append(employee.getPerformanceRating()).append("%\n");
        sb.append("--------------------------\n");
        return sb.toString();
    }
}