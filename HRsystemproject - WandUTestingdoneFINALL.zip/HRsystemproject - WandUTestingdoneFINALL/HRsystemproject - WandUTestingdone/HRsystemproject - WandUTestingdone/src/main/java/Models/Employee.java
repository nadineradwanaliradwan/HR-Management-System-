package Models;

public class Employee {
    private int employeeId;
    private String name;
    private String department;
    private String position;
    private double salary;
    private int remainingLeaveDays;
    private double performanceRating;
    private String password;

    // ---------- Constructors ----------
    public Employee(int employeeId, String name, String department, String position,
                    double salary, int remainingLeaveDays, double performanceRating, String password) {
        this.employeeId = employeeId;
        this.name = name;
        this.department = department;
        this.position = position;
        this.salary = salary;
        this.remainingLeaveDays = remainingLeaveDays;
        this.performanceRating = performanceRating;
        this.password = password;
    }

    public Employee(int employeeId, String name, String department, String position,
                    double salary, String password) {
        this(employeeId, name, department, position, salary, 30, 100.0, password);
    }

    // ---------- Getters ----------
    public int getEmployeeId() {
        return employeeId;
    }

    public String getName() {
        return name;
    }

    public String getDepartment() {
        return department;
    }

    public String getPosition() {
        return position;
    }

    public double getSalary() {
        return salary;
    }

    public int getRemainingLeaveDays() {
        return remainingLeaveDays;
    }

    public double getPerformanceRating() {
        return performanceRating;
    }

    public String getPassword() {
        return password;
    }

    // ---------- Setters ----------
    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public void setRemainingLeaveDays(int remainingLeaveDays) {
        this.remainingLeaveDays = remainingLeaveDays;
    }

    public void setPerformanceRating(double performanceRating) {
        this.performanceRating = performanceRating;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    // ---------- toString (optional) ----------
    @Override
    public String toString() {
        return employeeId + " - " + name + " (" + position + ")";
    }
}
